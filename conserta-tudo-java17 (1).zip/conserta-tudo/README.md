# Conserta Tudo — Sistema de Gestão de Serviços de Manutenção Residencial

Trabalho da P2 de Programação Orientada a Objetos (Java).
Sistema de **console** que gerencia clientes, técnicos e ordens de serviço da empresa
"Conserta Tudo" (elétrica, hidráulica e reparos gerais), com alocação de técnicos,
atendimento prioritário de emergências, programa de fidelidade, pagamentos e relatórios.
Os dados são salvos em arquivos **CSV**.

## Requisitos

- **Java 17 ou superior** (testado com o JDK 21). Verifique com `java -version` e `javac -version`.
- Nenhuma biblioteca externa e nenhum Maven/Gradle: só o JDK.

## Como executar (passo a passo)

### Linux / macOS

```bash
./executar.sh            # compila e abre o sistema
./executar.sh testes     # compila e roda os testes
```

### Windows (Prompt de Comando)

```bat
executar.bat             :: compila e abre o sistema
executar.bat testes      :: compila e roda os testes
```

> No Windows, se os acentos aparecerem errados, rode `chcp 65001` antes.

### Manualmente (qualquer sistema)

```bash
mkdir out
javac --release 17 -encoding UTF-8 -d out $(find src -name "*.java")   # Linux/macOS
java -cp out consertatudo.Main                                          # abre o sistema
java -cp out consertatudo.TestesSistema                                 # roda os testes
```

No Windows (cmd), liste os arquivos assim: `dir /s /b src\*.java > fontes.txt` e compile com
`javac --release 17 -encoding UTF-8 -d out @fontes.txt`.

Os dados ficam na pasta `dados/` (criada automaticamente). Para usar outra pasta:
`java -cp out consertatudo.Main minha-pasta`.

### Roteiro rápido de demonstração

1. Abra o sistema e escolha **7 – Carregar dados de demonstração**.
2. **2 – Técnicos → Listar**: o eletricista aparece *BLOQUEADO* (está em uma emergência).
3. **4 – Ordens → Fila de alocação**: a ordem normal elétrica espera na fila.
4. **4 – Ordens → Iniciar / Concluir** a emergência: o eletricista é liberado e a ordem da fila é alocada sozinha.
5. **5 – Pagamentos → Registrar pagamento**: veja desconto de fidelidade, pontos e resgate.
6. **6 – Relatórios**: relatório geral, por período, histórico do cliente e exportação para `.txt`.

## Funcionalidades (requisitos do enunciado)

| Requisito | Onde está |
|---|---|
| Cadastro de serviços (elétrica R$ 150, hidráulica R$ 130, geral R$ 100) | `TipoServico` + menu *Catálogo de serviços* |
| Cadastro, edição e remoção de clientes e técnicos | menus *Clientes* e *Técnicos* |
| Alocação por disponibilidade e tipo de serviço | `OrdemServicoService.escolherTecnico` |
| Ordens com descrição, técnico e prazo | `OrdemServico`, menu *Ordens de serviço* |
| Status pendente / em andamento / concluída / cancelada | `StatusOrdem` + transições validadas em `OrdemServico` |
| Só ordens concluídas podem ser pagas | `OrdemServico.marcarComoPaga` e `PagamentoService.cotar` |
| Emergência: prioridade na alocação e taxa de 50% | `OrdemEmergencia`, `OrdemServicoService.filaDeAlocacao` |
| Bloqueio do técnico durante emergência | `OrdemServicoService.temEmergenciaAtiva` |
| 10% de desconto por ordem concluída (máx. 40%) | `PoliticaFidelidade.percentualDesconto` |
| 1 ponto a cada R$ 10 pagos; 100 pontos = R$ 20 de desconto | `PoliticaFidelidade` + `PagamentoService` |
| Histórico de pagamentos por cliente | menu *Pagamentos* / `RelatorioService.gerarHistoricoCliente` |
| Relatório com total de ordens realizadas e faturamento | `RelatorioService.gerarRelatorioGeral` |

**Extras:** relatório por período, faturamento por tipo de serviço, ordens concluídas por técnico,
exportação do relatório para `.txt`, ativar/desativar técnico, fila de alocação visível,
troca manual de técnico, dados de demonstração e testes automatizados.

## Decisões de regra de negócio (interpretações do enunciado)

- **Especialidade:** elétrica e hidráulica só podem ser feitas pelo técnico da especialidade; *reparos gerais* podem ser feitos por qualquer técnico.
- **Escolha do técnico:** entre os elegíveis (ativos, que atendem o tipo e sem emergência em aberto), vence quem tem **menos ordens em aberto**; empate favorece o especialista exato e depois o menor ID.
- **Prioridade:** ordens sem técnico formam uma fila ordenada por **emergência primeiro**, depois menor prazo, depois ordem de criação. Quando um técnico é liberado (ordem concluída/cancelada) ou cadastrado/ativado, a fila é alocada automaticamente.
- **Bloqueio:** enquanto um técnico tem uma ordem emergencial em aberto (pendente ou em andamento), ele **não recebe novos agendamentos** (automáticos ou manuais) e não inicia ordens normais.
- **Um técnico só executa uma ordem por vez** (uma ordem em andamento).
- **Desconto de fidelidade:** calculado na **criação** da ordem, pela quantidade de ordens concluídas do cliente até aquele momento (10% cada, teto de 40%), e fica registrado na ordem.
- **Taxa de emergência:** 50% sobre o valor base (ex.: elétrica emergencial = R$ 225,00). O desconto de fidelidade incide sobre esse valor.
- **Pontos:** 1 ponto por R$ 10,00 efetivamente **pagos** (parte inteira). O resgate troca blocos de 100 pontos por R$ 20,00, sem deixar o total negativo, e é opcional no momento do pagamento.
- **Remoção:** cliente ou técnico com ordens registradas não pode ser removido (para preservar o histórico); técnicos podem ser desativados.

## Aplicação dos princípios de POO

- **Abstração:** `Pessoa` e `OrdemServico` são classes abstratas que definem o que é comum e deixam o resto para as subclasses.
- **Herança:** `Cliente` e `Tecnico` estendem `Pessoa`; `OrdemNormal` e `OrdemEmergencia` estendem `OrdemServico`.
- **Polimorfismo:** o cálculo do valor chama `getTaxaAdicional()`, e cada subclasse responde do seu jeito (0% ou 50%); o mesmo vale para `isEmergencia()` e `getPapel()`. Nenhum `if` sobre o tipo da ordem espalhado pelo código.
- **Encapsulamento:** atributos privados; mudanças só por métodos que validam (`setNome`, `iniciar()`, `concluir()`, `debitarPontos()`...). Uma ordem nunca fica em estado inválido.
- **Outros padrões:** *Factory* (`OrdemFactory`), repositório genérico (`RepositorioCsv<T>`), serviços com injeção de dependência (`Sistema` monta tudo) e `Clock` injetável para testar datas.

## Estrutura do projeto

```
src/main/java/consertatudo/
├── Main.java                 ponto de entrada
├── Sistema.java              monta repositórios e serviços (composição)
├── DadosDemonstracao.java    cenário de exemplo
├── model/                    entidades e regras do domínio (Pessoa, Cliente, Tecnico,
│                             OrdemServico, OrdemNormal, OrdemEmergencia, Pagamento,
│                             TipoServico, StatusOrdem, PoliticaFidelidade, ...)
├── persistence/              RepositorioCsv<T> e um repositório por entidade
├── service/                  regras de negócio (Cliente, Tecnico, OrdemServico,
│                             Pagamento, Relatorio)
├── ui/                       ConsoleUI (menus) e Entrada (leitura segura do teclado)
├── util/                     Csv, Datas, Dinheiro
└── exception/                RegraNegocioException, EntidadeNaoEncontrada, Persistencia
src/test/java/consertatudo/TestesSistema.java   testes automatizados (sem dependências)
```

Camadas: **ui → service → persistence/model**. A interface não tem regra de negócio e o modelo não conhece a interface.

## Persistência (CSV)

Arquivos na pasta `dados/` (separador `;`, UTF-8, primeira linha = cabeçalho):

- `clientes.csv`: `id;nome;telefone;pontos`
- `tecnicos.csv`: `id;nome;telefone;especialidade;ativo`
- `ordens.csv`: `id;categoria;clienteId;tipo;descricao;prazo;criadaEm;status;tecnicoId;descontoFidelidade;paga`
- `pagamentos.csv`: `id;ordemId;clienteId;valorServico;descontoFidelidade;descontoPontos;pontosUsados;valorPago;pontosGanhos;data;forma`

Os dados são gravados a cada alteração (escrita em arquivo temporário seguida de substituição, para não corromper o arquivo).

## Tratamento de erros

- Entradas inválidas (letras, números fora da faixa, datas erradas, respostas diferentes de s/n) repetem a pergunta.
- Regras violadas (pagar ordem não concluída, prazo no passado, técnico bloqueado, ID inexistente...) mostram uma mensagem clara e voltam ao menu.
- Arquivo ou pasta ausente: o sistema começa vazio e cria os arquivos ao salvar.
- Linha corrompida em um CSV: é ignorada com um aviso, e o resto dos dados é carregado.
- Qualquer erro inesperado em uma ação é capturado no menu, sem encerrar o programa.

## Testes

`java -cp out consertatudo.TestesSistema` executa 14 testes cobrindo valores e taxa de emergência,
desconto de fidelidade (inclusive o teto de 40%), pontos e resgate, pagamento, transições de status,
bloqueio e prioridade de emergência, especialidade, validações, persistência (com `;` e aspas no texto),
arquivos ausentes/corrompidos, remoção com histórico e relatórios.

## Não implementado (desafios opcionais do enunciado)

- Relatório em **PDF com iText** (o relatório sai no console e em `.txt`).
- Salvar os arquivos de dados no **Google Drive**.
